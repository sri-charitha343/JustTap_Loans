import { SafeAreaView, StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ActivityPage = () => {
  return (
    <SafeAreaView style={styles.Container}>
      

    </SafeAreaView>
  )
}

export default ActivityPage

const styles = StyleSheet.create({
   
});